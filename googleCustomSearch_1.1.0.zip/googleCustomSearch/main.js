class GoogleCustomSearchEnginePlugin {
	constructor (API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions () {
		this.API.addInsertion('customSearchInput', this.addSearchInput, 1, this);
		this.API.addInsertion('customSearchContent', this.addSearchContent, 1, this);
	}

	escapeAttribute (value) {
		return String(value ?? '')
			.replace(/&/g, '&amp;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	escapeText (value) {
		return String(value ?? '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	serializeForScript (value) {
		return JSON.stringify(String(value ?? ''))
			.replace(/</g, '\\u003C')
			.replace(/\u2028/g, '\\u2028')
			.replace(/\u2029/g, '\\u2029');
	}

	getSearchId () {
		const searchId = String(this.config.searchId || '').trim();

		return /^[A-Za-z0-9:_-]+$/.test(searchId) ? searchId : '';
	}

	getSearchParam () {
		const searchParam = String(this.config.searchParam || '').trim();

		return /^[A-Za-z0-9_-]+$/.test(searchParam) ? searchParam : 'q';
	}

	getSearchUrl (rendererInstance) {
		if (rendererInstance.globalContext && rendererInstance.globalContext.website) {
			return rendererInstance.globalContext.website.searchUrl || '';
		}

		return '';
	}

	getCookieGroup () {
		const group = String(this.config.cookieBannerGroup || '').trim();

		return /^[A-Za-z0-9_-]+$/.test(group) ? group : '';
	}

	getSubmitButton (className) {
		return `<button type="submit" class="${className}"><span>${this.escapeText(this.config.searchSubmitLabel)}</span></button>`;
	}

	getLoaderScript (searchId, cookieGroup) {
		const type = cookieGroup ? ` type="gdpr-blocker/${cookieGroup}"` : '';

		return `
			<script${type}>
				(function () {
					var script = document.createElement('script');
					script.async = true;
					script.src = 'https://cse.google.com/cse.js?cx=' + encodeURIComponent(${this.serializeForScript(searchId)});
					document.head.appendChild(script);
				}());
			</script>
		`;
	}

	getConsentMarkup (cookieGroup) {
		if (!cookieGroup) {
			return { notice: '', script: '' };
		}

		const notice = `
			<div
				role="status"
				data-gdpr-group="gdpr-blocker/${cookieGroup}"
				data-google-search-consent-notice="${cookieGroup}"
				style="color: #666; display: block; margin-top: 1rem; padding: 10px 0; width: 100%;">
				${this.escapeText(this.config.cookieBannerNoConsentText)}
			</div>
		`;
		const script = `
			<script>
				document.body.addEventListener('publii-cookie-banner-unblock-${cookieGroup}', function () {
					var notices = document.querySelectorAll('[data-google-search-consent-notice="${cookieGroup}"]');

					for (var i = 0; i < notices.length; i++) {
						notices[i].style.display = 'none';
					}
				}, false);
			</script>
		`;

		return { notice, script };
	}

	getPreviewNotice (message) {
		return `<div role="status" data-search-preview-notice="google-custom-search" style="color: #666; display: block; margin-top: 1rem; padding: 10px 0; width: 100%;">${this.escapeText(message)}</div>`;
	}

	addSearchInput (rendererInstance) {
		const searchUrl = this.getSearchUrl(rendererInstance);
		const placeholder = this.escapeAttribute(this.config.searchPlaceholder);
		const autofocus = this.config.searchAutofocus ? ' autofocus' : '';
		const submitButton = this.config.searchSubmitButtonInBox ? this.getSubmitButton('search__button') : '';

		return `
			<form action="${this.escapeAttribute(searchUrl)}" class="search__form" role="search">
				<input
					class="search__input"
					type="search"
					name="${this.getSearchParam()}"
					placeholder="${placeholder}"
					aria-label="${placeholder}"${autofocus}>
				${submitButton}
			</form>
		`;
	}

	addSearchContent (rendererInstance) {
		const searchUrl = this.getSearchUrl(rendererInstance);
		const searchId = this.getSearchId();
		const searchParam = this.getSearchParam();
		const previewMode = Boolean(rendererInstance.previewMode);
		const placeholder = this.escapeAttribute(this.config.searchPlaceholder);
		const cookieGroup = this.config.cookieBannerIntegration ? this.getCookieGroup() : '';
		const hasInvalidCookieConfiguration = this.config.cookieBannerIntegration && !cookieGroup;
		const shouldLoad = searchId && !hasInvalidCookieConfiguration;
		const consent = shouldLoad ? this.getConsentMarkup(cookieGroup) : { notice: '', script: '' };
		const submitButton = this.config.searchSubmitButtonOnPage ? this.getSubmitButton('search-page-button') : '';
		let statusNotice = '';
		let results = '';
		let loader = '';

		if (previewMode && !searchId) {
			statusNotice = this.getPreviewNotice('Search results cannot be displayed because the Search engine ID is missing or invalid. Add it in the plugin settings.');
		} else if (previewMode && hasInvalidCookieConfiguration) {
			statusNotice = this.getPreviewNotice('Search results cannot be displayed because the Cookie Group ID is missing or invalid. Check the plugin settings.');
		} else if (!searchId) {
			statusNotice = '<!-- Google Custom Search: A valid Search engine ID is required. -->';
		} else if (hasInvalidCookieConfiguration) {
			statusNotice = '<!-- Google Custom Search: Cookie Banner integration requires a valid Cookie Group ID. -->';
		}

		if (shouldLoad) {
			results = `<div class="gcse-searchresults-only" data-queryParameterName="${searchParam}"></div>`;
			loader = this.getLoaderScript(searchId, cookieGroup);
		}

		return `
			<form action="${this.escapeAttribute(searchUrl)}" class="search-page-form" role="search">
				<input
					type="search"
					name="${searchParam}"
					placeholder="${placeholder}"
					aria-label="${placeholder}"
					class="search-page-input">
				${submitButton}
			</form>
			${statusNotice}
			${consent.notice}
			${results}
			${loader}
			${consent.script}
		`;
	}
}

module.exports = GoogleCustomSearchEnginePlugin;
